﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronBridge.Data
{
    public class TarjetaCredito : IMetodoPago
    {
        public void ProcesarPago(decimal monto)
        {
            Console.WriteLine("Pago de ${0} procesado via Tarjeta de credito.", monto);
        }
    }
}
