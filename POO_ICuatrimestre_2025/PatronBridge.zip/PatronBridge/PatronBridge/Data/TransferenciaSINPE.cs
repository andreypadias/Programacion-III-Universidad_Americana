﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronBridge.Data
{
    public class TransferenciaSINPE:IMetodoPago
    {
        public void ProcesarPago(decimal monto)
        {
            Console.WriteLine("Pago de ${0} procesado via SINPE.", monto);
        }
    }
}
