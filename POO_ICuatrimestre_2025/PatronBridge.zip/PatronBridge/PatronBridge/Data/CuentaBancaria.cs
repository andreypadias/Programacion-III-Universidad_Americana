﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronBridge.Data
{
    public abstract class CuentaBancaria
    {
        protected IMetodoPago MetodoPago;

        public CuentaBancaria(IMetodoPago metodoPago)
        {
              MetodoPago = metodoPago;
        }
        public abstract void RealizarPago(decimal monto);
    }
}
