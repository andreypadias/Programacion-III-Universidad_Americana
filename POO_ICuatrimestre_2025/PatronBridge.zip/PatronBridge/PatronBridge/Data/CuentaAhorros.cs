﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronBridge.Data
{
    public class CuentaAhorros : CuentaBancaria
    {
        public CuentaAhorros(IMetodoPago metodoPago) : base(metodoPago){}

        public override void RealizarPago(decimal monto)
        {
            Console.WriteLine("Pago desde la cuenta de ahorros:\n");
            MetodoPago.ProcesarPago(monto);
        }
    }
}
