﻿// See https://aka.ms/new-console-template for more information

using PatronBridge.Data;

CuentaBancaria cuentaPersonal = new CuentaAhorros(new TransferenciaSINPE());
cuentaPersonal.RealizarPago(800);

/*TarjetaCredito tarjetaCreditoPersonal = new TarjetaCredito();

TransferenciaBancaria transferenciaBancariaPersonal = new TransferenciaBancaria();

CuentaAhorros cuentaAhorroPersonal = new CuentaAhorros(transferenciaBancariaPersonal);

cuentaAhorroPersonal.RealizarPago(5000);*/

