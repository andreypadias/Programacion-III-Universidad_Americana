﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Semana12.Models;

public partial class Reserva
{
    public int Id { get; set; }

    public int IdCliente { get; set; }

    public int IdServicio { get; set; }

    public DateTime FechaCita { get; set; }

    public string? Notas { get; set; }

    [ForeignKey("IdCliente")]
    public virtual Cliente Cliente { get; set; } = null!;

    [ForeignKey("IdServicio")]
    public virtual Servicio Servicio { get; set; } = null!;
}
