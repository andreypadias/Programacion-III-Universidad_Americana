﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Semana9.Models
{
    public class Factura
    {
        [Key]
        public int Id { get; set; }

        public string Detalle { get; set; }
        
        public DateTime Fecha { get; set; }

        
        public Decimal Total { get; set; }

        public Cliente Cliente { get; set; }

        
        public int ClienteId { get; set; }
    }
}
