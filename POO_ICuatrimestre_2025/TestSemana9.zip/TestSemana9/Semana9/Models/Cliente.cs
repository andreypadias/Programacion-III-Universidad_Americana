﻿using System.ComponentModel.DataAnnotations;

namespace Semana9.Models
{
    public class Cliente
    {
        [Key]
        public int Id { get; set; }

        public string Nombre { get; set; }

        public string Email { get; set; }


        //Relacion uno a muchos, un cliente puede tener muchas facturas.
        public ICollection<Factura> Facturas { get; set; }
    }
}
