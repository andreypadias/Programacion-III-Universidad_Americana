﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Semana9.Models;
using System.Reflection.Metadata;

namespace Semana9.Data
{
    public class ApplicationDBcontext : DbContext
    {
        public ApplicationDBcontext(DbContextOptions<ApplicationDBcontext> options) : base(options)
        {

        }

        //Metodo opcional para forzar las relaciones.
        /*protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Cliente>()
                .HasMany(e => e.Facturas)
                .WithOne(e => e.Cliente)
                .HasForeignKey(e => e.ClienteId);
            

            modelBuilder.Entity<Factura>()
               .HasOne(e => e.Cliente)
               .WithMany(e => e.Facturas)
               .HasForeignKey(e => e.ClienteId);
        }*/

        public DbSet<Cliente> Clientes { get; set; }

        public DbSet<Factura> Facturas { get; set; }
    }
}
