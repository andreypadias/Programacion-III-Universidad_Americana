﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MuchosAmuchos.Models
{
    public class EstudianteCurso
    {
        [Key]
        public int Id { get; set; }

        public int EstudianteId { get; set; }

        public int CursoId { get; set; }

        [ForeignKey("EstudianteId")]
        public virtual Estudiante Estudiante { get; set; }

        [ForeignKey("CursoId")]
        public virtual Curso Curso { get; set; }

    }
}
