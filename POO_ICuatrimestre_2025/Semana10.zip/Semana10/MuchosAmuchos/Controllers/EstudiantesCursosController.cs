﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MuchosAmuchos.Data;
using MuchosAmuchos.Models;

namespace MuchosAmuchos.Controllers
{
    public class EstudiantesCursosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EstudiantesCursosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: EstudiantesCursos
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.EstudiantesCursos.Include(e => e.Curso).Include(e => e.Estudiante);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: EstudiantesCursos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var estudianteCurso = await _context.EstudiantesCursos
                .Include(e => e.Curso)
                .Include(e => e.Estudiante)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (estudianteCurso == null)
            {
                return NotFound();
            }

            return View(estudianteCurso);
        }

        // GET: EstudiantesCursos/Create
        public IActionResult Create()
        {
            ViewData["CursoId"] = new SelectList(_context.Cursos, "Id", "Nombre");
            ViewData["EstudianteId"] = new SelectList(_context.Estudiantes, "Id", "Nombre");
            return View();
        }

        // POST: EstudiantesCursos/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EstudianteId,CursoId")] EstudianteCurso estudianteCurso)
        {
            try
            {
                _context.Add(estudianteCurso);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception)
            {

                throw;
            }
            ViewData["CursoId"] = new SelectList(_context.Cursos, "Id", "Id", estudianteCurso.CursoId);
            ViewData["EstudianteId"] = new SelectList(_context.Estudiantes, "Id", "Id", estudianteCurso.EstudianteId);
            return View(estudianteCurso);
        }

        // GET: EstudiantesCursos/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var estudianteCurso = await _context.EstudiantesCursos.FindAsync(id);
            if (estudianteCurso == null)
            {
                return NotFound();
            }
            ViewData["CursoId"] = new SelectList(_context.Cursos, "Id", "Id", estudianteCurso.CursoId);
            ViewData["EstudianteId"] = new SelectList(_context.Estudiantes, "Id", "Id", estudianteCurso.EstudianteId);
            return View(estudianteCurso);
        }

        // POST: EstudiantesCursos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,EstudianteId,CursoId")] EstudianteCurso estudianteCurso)
        {
            if (id != estudianteCurso.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(estudianteCurso);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EstudianteCursoExists(estudianteCurso.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CursoId"] = new SelectList(_context.Cursos, "Id", "Id", estudianteCurso.CursoId);
            ViewData["EstudianteId"] = new SelectList(_context.Estudiantes, "Id", "Id", estudianteCurso.EstudianteId);
            return View(estudianteCurso);
        }

        // GET: EstudiantesCursos/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var estudianteCurso = await _context.EstudiantesCursos
                .Include(e => e.Curso)
                .Include(e => e.Estudiante)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (estudianteCurso == null)
            {
                return NotFound();
            }

            return View(estudianteCurso);
        }

        // POST: EstudiantesCursos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var estudianteCurso = await _context.EstudiantesCursos.FindAsync(id);
            if (estudianteCurso != null)
            {
                _context.EstudiantesCursos.Remove(estudianteCurso);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EstudianteCursoExists(int id)
        {
            return _context.EstudiantesCursos.Any(e => e.Id == id);
        }
    }
}
