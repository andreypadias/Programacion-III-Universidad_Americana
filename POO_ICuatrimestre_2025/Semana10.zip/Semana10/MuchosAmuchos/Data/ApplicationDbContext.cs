﻿using Microsoft.EntityFrameworkCore;
using MuchosAmuchos.Models;

namespace MuchosAmuchos.Data
{
    public class ApplicationDbContext:DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>options):base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EstudianteCurso>()
                .HasKey(ec => ec.Id);

            modelBuilder.Entity<EstudianteCurso>()
                .HasOne(ec => ec.Estudiante)
                .WithMany(e => e.EstudiantesCursos)
                .HasForeignKey(ec => ec.EstudianteId);

            modelBuilder.Entity<EstudianteCurso>()
                .HasOne(ec => ec.Curso)
                .WithMany(c => c.EstudiantesCursos)
                .HasForeignKey(ec => ec.CursoId);

        }

        public DbSet<Estudiante> Estudiantes { get; set; }

        public DbSet<Curso> Cursos { get; set; }

        public DbSet<EstudianteCurso> EstudiantesCursos { get; set; }
    }
}
