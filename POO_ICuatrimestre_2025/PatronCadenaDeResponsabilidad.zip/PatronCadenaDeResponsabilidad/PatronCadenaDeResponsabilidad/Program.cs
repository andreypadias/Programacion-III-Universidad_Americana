﻿// See https://aka.ms/new-console-template for more information
using PatronCadenaDeResponsabilidad.Data;

Console.WriteLine("******CADENA DE RESPONSABILIDAD****** \n ******APROBACION DE COMPRAS******");

IAprobador gerente = new Gerente();
IAprobador director = new Director();
IAprobador ceo = new CEO();

gerente.EstablecerSiguienteAprobador(director);
director.EstablecerSiguienteAprobador(ceo);

gerente.ProcesarSolicitud(new SolicitudCompra(500));
gerente.ProcesarSolicitud(new SolicitudCompra(5000));
gerente.ProcesarSolicitud(new SolicitudCompra(15000));

