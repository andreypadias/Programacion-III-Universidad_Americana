﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronCadenaDeResponsabilidad.Data
{
    public class Gerente:Aprobador
    {
        public override void ProcesarSolicitud(SolicitudCompra solicitudCompra)
        {
            if (solicitudCompra.Monto <= 1000)
            {
                Console.WriteLine("El gerente es capaz de procesar esta solicitud. \nSe aprobo la compra de $" + solicitudCompra.Monto);
            }
            else
            {
                SiguienteAprobador?.ProcesarSolicitud(solicitudCompra);
            }
        }
    }
}
