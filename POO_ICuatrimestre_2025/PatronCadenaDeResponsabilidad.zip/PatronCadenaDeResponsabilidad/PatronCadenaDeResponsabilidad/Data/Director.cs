﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronCadenaDeResponsabilidad.Data
{
    public class Director : Aprobador
    {
        public override void ProcesarSolicitud(SolicitudCompra solicitudCompra)
        {
            if (solicitudCompra.Monto <= 10000)
            {
                Console.WriteLine("El director es capaz de procesar esta solicitud. \nSe aprobo la compra de $" + solicitudCompra.Monto);
            }
            else 
            {
                SiguienteAprobador?.ProcesarSolicitud(solicitudCompra);
            }
        }
    }
}
