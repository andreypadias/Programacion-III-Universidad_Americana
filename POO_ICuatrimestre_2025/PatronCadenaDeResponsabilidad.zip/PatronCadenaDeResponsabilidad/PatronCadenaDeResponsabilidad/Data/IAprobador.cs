﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronCadenaDeResponsabilidad.Data
{
    //Esta interfaz es mi manejador (handler)
    public interface IAprobador
    {
        void EstablecerSiguienteAprobador(IAprobador siguienteAprobador);
        void ProcesarSolicitud(SolicitudCompra solicitudCompra);

    }
}
