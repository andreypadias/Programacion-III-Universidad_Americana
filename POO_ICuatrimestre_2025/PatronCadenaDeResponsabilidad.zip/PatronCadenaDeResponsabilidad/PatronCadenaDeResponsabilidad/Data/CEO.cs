﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronCadenaDeResponsabilidad.Data
{
    public class CEO:Aprobador
    {
        public override void ProcesarSolicitud(SolicitudCompra solicitudCompra)
        {
            Console.WriteLine("El CEO es capaz de procesar esta solicitud. \nSe aprobo la compra de $" + solicitudCompra.Monto);
        }
    }
}
