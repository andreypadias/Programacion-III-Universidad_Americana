﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronCadenaDeResponsabilidad.Data
{
    public abstract class Aprobador:IAprobador
    {
        public string Nombre { get; set; }
        public string CorreoElectronico { get; set; }

        protected IAprobador SiguienteAprobador;

        public void EstablecerSiguienteAprobador(IAprobador siguienteAprobador)
        {
            SiguienteAprobador = siguienteAprobador;
        }

        public abstract void ProcesarSolicitud(SolicitudCompra solicitudCompra);
        
    }
}
