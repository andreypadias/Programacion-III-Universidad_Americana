﻿// See https://aka.ms/new-console-template for more information
using FactoryMethod.Data;


Console.WriteLine("Ingrese el formato del reporte que desea generar:");
string tipoReporte = Console.ReadLine().ToUpper();

string datosReporte = "Estos son los datos del reporte.";

IReporte reporte = ReporteFactory.CrearReporte(tipoReporte);

reporte.Generar(datosReporte);