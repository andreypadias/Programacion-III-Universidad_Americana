﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethod.Data
{
    public class ReporteFactory
    {
        public static IReporte CrearReporte(string TipoReporte) 
        {
            
            return TipoReporte switch
            {
                "PDF" => new ReportePDF(),
                "EXCEL" => new ReporteExcel(),
                "CSV"=> new ReporteCSV(),
                "DOCX" => new ReporteDOCX(),
                _=> throw new ArgumentException("Formato Incorrecto")
            };
        }
    }
}
