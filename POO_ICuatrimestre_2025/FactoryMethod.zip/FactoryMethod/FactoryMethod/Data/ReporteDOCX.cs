﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethod.Data
{
    public class ReporteDOCX : IReporte
    {
        public void Generar(string datos)
        {
            Console.WriteLine($"Reporte en Word \n Informacion: {datos}");
        }
    }
}
