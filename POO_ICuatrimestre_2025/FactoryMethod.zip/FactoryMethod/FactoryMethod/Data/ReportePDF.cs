﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethod.Data
{
    public class ReportePDF : IReporte
    {
        public void Generar(string datos)
        {
            Console.WriteLine($"Reporte en PDF \n Informacion: {datos}");
        }
    }
}
