﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaAlquilerDeVehiculos.Data
{
    public class Barco : Vehiculo
    {
        public Barco(string placa, string modelo) : base(placa, modelo)
        {
        }
    }
}
