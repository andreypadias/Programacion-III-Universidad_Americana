﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaAlquilerDeVehiculos.Data
{
    public class SUV : Vehiculo,IAlquiler,IMantemiento
    {
        public string Traccion { get; set; }
        public bool EstaAlquilado { get; set; }

        public SUV(string placa, string modelo) : base(placa, modelo)
        {
            EstaAlquilado=false;
        }

        public void Alquilar()
        {
            if (!EstaAlquilado)
            {
                Console.WriteLine("Se ha alquilado el vehiculo.");
                EstaAlquilado = true;
            }
            else 
            {
                Console.WriteLine("Este vehiculo no esta disponible para el alquiler");
            }
        }

        public void Devolver()
        {
            if (EstaAlquilado)
            {
                Console.WriteLine("Se ha devuelto el vehiculo.");
                EstaAlquilado = false;
            }
            else
            {
                Console.WriteLine("Este vehiculo no estaba alquilado!");
            }
        }

        public void AplicarMantenimiento()
        {
            Console.WriteLine("Aplicando Mantenimiento....\n Mantenimiento aplicado!");
        }
    }
}
