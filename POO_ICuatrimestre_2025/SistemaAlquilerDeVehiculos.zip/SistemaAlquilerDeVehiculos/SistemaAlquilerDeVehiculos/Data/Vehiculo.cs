﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaAlquilerDeVehiculos.Data
{
    public abstract class Vehiculo
    {
        public string Placa { get; set; }
        public string Modelo { get; set; }
        public int Anho { get; set; }

        public Vehiculo(string placa, string modelo)
        {
            Placa = placa;
            Modelo = modelo;
        }

        public void MostrarInformacion() 
        {
            Console.WriteLine($"Informacion: \n Placa: {Placa} - Modelo: {Modelo}");
        }

    }
}
