﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaAlquilerDeVehiculos.Data
{
    public class Sedan : Vehiculo
    {
        public int NumeroPuertas { get; set; }
        public Sedan(string placa, string modelo) : base(placa, modelo)
        {
        }



    }
}
